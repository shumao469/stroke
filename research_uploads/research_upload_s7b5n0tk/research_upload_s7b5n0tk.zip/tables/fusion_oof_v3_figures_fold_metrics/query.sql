SELECT * FROM "fusion_oof_v3_figures_fold_metrics";

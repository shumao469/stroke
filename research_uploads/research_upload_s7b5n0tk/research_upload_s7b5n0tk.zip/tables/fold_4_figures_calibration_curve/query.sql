SELECT * FROM "fold_4_figures_calibration_curve";

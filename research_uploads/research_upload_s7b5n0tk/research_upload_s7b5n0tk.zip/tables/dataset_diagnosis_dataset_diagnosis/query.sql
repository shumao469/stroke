SELECT * FROM "dataset_diagnosis_dataset_diagnosis";

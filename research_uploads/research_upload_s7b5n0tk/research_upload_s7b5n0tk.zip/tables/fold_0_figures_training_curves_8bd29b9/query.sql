SELECT * FROM "fold_0_figures_training_curves_8bd29b9";

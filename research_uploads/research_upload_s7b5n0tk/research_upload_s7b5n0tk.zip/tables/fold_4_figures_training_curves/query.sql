SELECT * FROM "fold_4_figures_training_curves";

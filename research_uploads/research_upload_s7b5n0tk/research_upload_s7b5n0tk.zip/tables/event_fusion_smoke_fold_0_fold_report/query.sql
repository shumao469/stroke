SELECT * FROM "event_fusion_smoke_fold_0_fold_report";

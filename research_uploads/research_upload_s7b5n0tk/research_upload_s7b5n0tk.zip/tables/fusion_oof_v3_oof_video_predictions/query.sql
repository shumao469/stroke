SELECT * FROM "fusion_oof_v3_oof_video_predictions";

SELECT * FROM "event_fusion_smoke_figures_threshold_curve";

SELECT * FROM "output_filter_event_0_h_left_l_2025_10_28_19_17_58_a";

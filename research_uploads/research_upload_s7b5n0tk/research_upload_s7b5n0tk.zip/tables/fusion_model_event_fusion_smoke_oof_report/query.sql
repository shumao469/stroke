SELECT * FROM "fusion_model_event_fusion_smoke_oof_report";

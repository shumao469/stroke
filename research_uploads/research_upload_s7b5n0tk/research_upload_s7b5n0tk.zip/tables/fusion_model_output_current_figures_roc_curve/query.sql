SELECT * FROM "fusion_model_output_current_figures_roc_curve";

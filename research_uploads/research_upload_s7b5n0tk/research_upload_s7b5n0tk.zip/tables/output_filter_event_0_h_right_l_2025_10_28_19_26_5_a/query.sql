SELECT * FROM "output_filter_event_0_h_right_l_2025_10_28_19_26_5_a";

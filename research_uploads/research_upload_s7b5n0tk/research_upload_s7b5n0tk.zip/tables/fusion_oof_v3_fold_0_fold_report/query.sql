SELECT * FROM "fusion_oof_v3_fold_0_fold_report";

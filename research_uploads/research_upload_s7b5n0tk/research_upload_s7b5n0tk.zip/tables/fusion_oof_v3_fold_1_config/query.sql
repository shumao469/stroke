SELECT * FROM "fusion_oof_v3_fold_1_config";

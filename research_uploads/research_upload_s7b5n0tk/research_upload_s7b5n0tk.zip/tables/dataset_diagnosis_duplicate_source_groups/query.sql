SELECT * FROM "dataset_diagnosis_duplicate_source_groups";

SELECT * FROM "fusion_oof_v3_resolved_tensor_manifest";

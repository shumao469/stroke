SELECT * FROM "fold_1_figures_training_curves";

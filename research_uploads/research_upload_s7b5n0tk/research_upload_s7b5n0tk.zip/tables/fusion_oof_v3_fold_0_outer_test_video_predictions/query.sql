SELECT * FROM "fusion_oof_v3_fold_0_outer_test_video_predictions";

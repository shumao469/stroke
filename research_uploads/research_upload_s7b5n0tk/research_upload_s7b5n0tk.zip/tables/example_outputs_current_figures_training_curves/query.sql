SELECT * FROM "example_outputs_current_figures_training_curves";

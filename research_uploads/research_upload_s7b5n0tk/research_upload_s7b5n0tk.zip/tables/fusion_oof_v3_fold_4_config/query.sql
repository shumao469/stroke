SELECT * FROM "fusion_oof_v3_fold_4_config";

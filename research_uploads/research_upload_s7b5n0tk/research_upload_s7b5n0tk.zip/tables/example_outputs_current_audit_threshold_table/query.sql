SELECT * FROM "example_outputs_current_audit_threshold_table";

SELECT * FROM "event_fusion_oof_fixed_fold_3_fold_report";

SELECT * FROM "fold_3_figures_pr_curve";

SELECT * FROM "fusion_model_output_current_audit_threshold_table";

SELECT * FROM "event_fusion_smoke_figures_figure_summary";

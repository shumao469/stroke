SELECT * FROM "example_outputs_current_figures_roc_curve";

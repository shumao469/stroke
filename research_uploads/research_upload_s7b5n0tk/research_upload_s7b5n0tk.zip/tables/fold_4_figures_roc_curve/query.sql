SELECT * FROM "fold_4_figures_roc_curve";

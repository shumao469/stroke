SELECT * FROM "locked_validation_v4_publication_table_model_perform";

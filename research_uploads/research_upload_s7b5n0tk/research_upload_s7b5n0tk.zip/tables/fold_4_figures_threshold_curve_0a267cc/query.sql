SELECT * FROM "fold_4_figures_threshold_curve_0a267cc";

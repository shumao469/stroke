SELECT * FROM "fold_0_figures_roc_curve_6e184a9";

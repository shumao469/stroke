SELECT * FROM "octa_fusion_locked_validation_v4_locked_test_manifes";

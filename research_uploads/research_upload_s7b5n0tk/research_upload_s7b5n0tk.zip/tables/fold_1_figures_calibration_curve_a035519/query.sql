SELECT * FROM "fold_1_figures_calibration_curve_a035519";

SELECT * FROM "fusion_oof_v3_fold_4_inner_val_video_predictions";

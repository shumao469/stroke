SELECT * FROM "fold_2_figures_calibration_curve_1152b67";

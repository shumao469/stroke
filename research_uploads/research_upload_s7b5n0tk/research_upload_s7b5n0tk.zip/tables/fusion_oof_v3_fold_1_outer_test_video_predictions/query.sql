SELECT * FROM "fusion_oof_v3_fold_1_outer_test_video_predictions";

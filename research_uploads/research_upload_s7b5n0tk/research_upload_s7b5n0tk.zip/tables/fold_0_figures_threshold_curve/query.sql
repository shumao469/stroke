SELECT * FROM "fold_0_figures_threshold_curve";

SELECT * FROM "event_fusion_smoke_figures_fold_metrics";

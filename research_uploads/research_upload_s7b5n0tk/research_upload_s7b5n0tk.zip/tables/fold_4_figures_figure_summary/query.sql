SELECT * FROM "fold_4_figures_figure_summary";

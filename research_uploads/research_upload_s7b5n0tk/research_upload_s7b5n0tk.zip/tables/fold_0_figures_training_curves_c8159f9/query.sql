SELECT * FROM "fold_0_figures_training_curves_c8159f9";

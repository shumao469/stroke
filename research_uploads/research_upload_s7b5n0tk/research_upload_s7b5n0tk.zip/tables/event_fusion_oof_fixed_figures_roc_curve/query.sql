SELECT * FROM "event_fusion_oof_fixed_figures_roc_curve";

SELECT * FROM "example_outputs_current_figures_threshold_curve";

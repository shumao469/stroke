SELECT * FROM "example_outputs_current_figures_figure_summary";

SELECT * FROM "output_filter_event_0_h_right_l";

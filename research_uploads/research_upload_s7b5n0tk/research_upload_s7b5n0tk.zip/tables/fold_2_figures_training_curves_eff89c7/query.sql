SELECT * FROM "fold_2_figures_training_curves_eff89c7";

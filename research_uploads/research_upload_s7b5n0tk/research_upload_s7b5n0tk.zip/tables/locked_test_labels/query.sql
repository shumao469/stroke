SELECT * FROM "locked_test_labels";

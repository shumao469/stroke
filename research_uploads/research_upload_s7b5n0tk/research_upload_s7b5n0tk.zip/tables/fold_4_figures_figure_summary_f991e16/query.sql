SELECT * FROM "fold_4_figures_figure_summary_f991e16";

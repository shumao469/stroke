SELECT * FROM "fusion_oof_v3_fold_3_inner_val_video_predictions";

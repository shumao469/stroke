SELECT * FROM "fold_3_figures_training_curves_12722f4";

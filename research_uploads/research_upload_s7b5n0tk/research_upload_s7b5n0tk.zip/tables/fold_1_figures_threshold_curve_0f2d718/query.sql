SELECT * FROM "fold_1_figures_threshold_curve_0f2d718";

SELECT * FROM "event_fusion_smoke_figures_pr_curve";

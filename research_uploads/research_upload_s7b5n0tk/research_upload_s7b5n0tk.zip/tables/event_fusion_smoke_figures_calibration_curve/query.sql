SELECT * FROM "event_fusion_smoke_figures_calibration_curve";

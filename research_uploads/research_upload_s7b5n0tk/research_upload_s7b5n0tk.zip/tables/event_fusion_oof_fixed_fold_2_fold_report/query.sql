SELECT * FROM "event_fusion_oof_fixed_fold_2_fold_report";

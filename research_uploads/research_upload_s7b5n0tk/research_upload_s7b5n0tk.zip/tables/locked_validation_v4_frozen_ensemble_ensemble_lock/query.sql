SELECT * FROM "locked_validation_v4_frozen_ensemble_ensemble_lock";

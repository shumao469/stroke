SELECT * FROM "fold_3_figures_calibration_curve_c4cbefa";

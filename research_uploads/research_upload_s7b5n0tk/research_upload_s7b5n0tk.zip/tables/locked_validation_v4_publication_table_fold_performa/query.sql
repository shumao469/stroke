SELECT * FROM "locked_validation_v4_publication_table_fold_performa";

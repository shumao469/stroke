SELECT * FROM "fusion_oof_v3_fold_3_config";

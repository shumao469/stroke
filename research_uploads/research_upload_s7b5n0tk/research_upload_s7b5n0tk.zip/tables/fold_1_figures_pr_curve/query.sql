SELECT * FROM "fold_1_figures_pr_curve";

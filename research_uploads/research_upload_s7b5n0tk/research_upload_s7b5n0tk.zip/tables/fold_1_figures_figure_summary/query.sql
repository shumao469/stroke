SELECT * FROM "fold_1_figures_figure_summary";

SELECT * FROM "fusion_oof_v3_figures_pr_curve";

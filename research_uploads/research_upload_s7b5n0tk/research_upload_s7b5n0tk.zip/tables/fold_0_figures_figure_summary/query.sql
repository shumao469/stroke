SELECT * FROM "fold_0_figures_figure_summary";

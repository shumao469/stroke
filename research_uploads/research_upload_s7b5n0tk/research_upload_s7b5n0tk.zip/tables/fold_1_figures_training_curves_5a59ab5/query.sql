SELECT * FROM "fold_1_figures_training_curves_5a59ab5";

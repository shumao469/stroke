SELECT * FROM "fold_3_figures_figure_summary";

SELECT * FROM "fold_1_figures_roc_curve";

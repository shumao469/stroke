SELECT * FROM "tensor_index_v3_qc";

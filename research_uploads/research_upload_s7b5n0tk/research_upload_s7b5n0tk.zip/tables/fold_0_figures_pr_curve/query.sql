SELECT * FROM "fold_0_figures_pr_curve";

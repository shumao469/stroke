SELECT * FROM "locked_validation_v4_duplicate_high_sensitivity_dupl";

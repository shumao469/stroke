SELECT * FROM "locked_test_source_original_encoding";

SELECT * FROM "fold_1_figures_roc_curve_28d078d";

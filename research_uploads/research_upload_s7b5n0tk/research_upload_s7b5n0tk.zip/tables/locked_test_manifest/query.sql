SELECT * FROM "locked_test_manifest";

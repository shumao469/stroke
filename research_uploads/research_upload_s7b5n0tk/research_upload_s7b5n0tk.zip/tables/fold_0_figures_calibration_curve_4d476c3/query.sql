SELECT * FROM "fold_0_figures_calibration_curve_4d476c3";

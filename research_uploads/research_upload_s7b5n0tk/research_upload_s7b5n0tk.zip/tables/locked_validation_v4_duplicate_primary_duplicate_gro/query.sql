SELECT * FROM "locked_validation_v4_duplicate_primary_duplicate_gro";

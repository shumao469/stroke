SELECT * FROM "fold_2_figures_figure_summary_e81b657";

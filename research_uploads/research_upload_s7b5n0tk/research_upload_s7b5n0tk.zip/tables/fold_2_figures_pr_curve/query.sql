SELECT * FROM "fold_2_figures_pr_curve";

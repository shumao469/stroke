SELECT * FROM "fold_0_figures_calibration_curve";

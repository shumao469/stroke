SELECT * FROM "fold_4_figures_training_curves_4711b6a";

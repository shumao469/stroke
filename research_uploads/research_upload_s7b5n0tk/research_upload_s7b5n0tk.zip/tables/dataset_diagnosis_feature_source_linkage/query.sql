SELECT * FROM "dataset_diagnosis_feature_source_linkage";

SELECT * FROM "fusion_model_output_best_val_segment_pred";

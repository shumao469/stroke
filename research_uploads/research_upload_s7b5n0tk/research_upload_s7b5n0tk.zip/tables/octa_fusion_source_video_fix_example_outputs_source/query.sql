SELECT * FROM "octa_fusion_source_video_fix_example_outputs_source";

SELECT * FROM "event_fusion_oof_fixed_fold_4_fold_report";

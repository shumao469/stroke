SELECT * FROM "fold_4_figures_pr_curve";

SELECT * FROM "fold_2_figures_threshold_curve_186081b";

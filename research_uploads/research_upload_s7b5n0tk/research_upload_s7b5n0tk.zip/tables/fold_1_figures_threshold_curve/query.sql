SELECT * FROM "fold_1_figures_threshold_curve";

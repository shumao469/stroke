SELECT * FROM "fold_2_figures_roc_curve";

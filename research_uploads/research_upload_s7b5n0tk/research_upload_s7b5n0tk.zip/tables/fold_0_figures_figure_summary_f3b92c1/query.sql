SELECT * FROM "fold_0_figures_figure_summary_f3b92c1";

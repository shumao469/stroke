SELECT * FROM "fold_2_figures_training_curves";

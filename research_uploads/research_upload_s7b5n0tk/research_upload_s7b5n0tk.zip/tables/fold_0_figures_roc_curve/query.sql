SELECT * FROM "fold_0_figures_roc_curve";

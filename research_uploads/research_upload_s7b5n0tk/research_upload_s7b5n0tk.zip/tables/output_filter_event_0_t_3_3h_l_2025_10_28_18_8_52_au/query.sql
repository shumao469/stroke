SELECT * FROM "output_filter_event_0_t_3_3h_l_2025_10_28_18_8_52_au";

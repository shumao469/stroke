# All-tables GPT analysis package

This package summarizes 317 DuckDB tables in one export operation.

## Read first

1. `TABLE_INDEX.csv`: every selected table, row count, column count and export status.
2. `ALL_SCHEMAS.csv`: consolidated field names and DuckDB types.
3. `COMMON_COLUMNS.csv`: same-name columns across tables. These are relationship hints, not proven join keys.
4. `MASTER_MANIFEST.json`: machine-readable package map.
5. `tables/<table>/preview.csv`: bounded preview for each table.

## Full data

Export mode: `overview`.

When full data are included, each table has its own `data_part_*.csv` sequence. Do not concatenate parts from different table directories. Within one table, concatenate parts in filename order and keep one header.

## Upload order

Upload the overview ZIP volume(s) first. Ask ChatGPT to inspect the global index and identify relevant tables. Upload the complete ZIP or data volume(s) only when row-level analysis is needed.

Failed tables remain listed in `TABLE_INDEX.csv`; never assume the package is complete without checking the status column.

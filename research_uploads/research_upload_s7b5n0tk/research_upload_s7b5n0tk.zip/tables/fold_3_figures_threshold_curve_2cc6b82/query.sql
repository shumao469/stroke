SELECT * FROM "fold_3_figures_threshold_curve_2cc6b82";

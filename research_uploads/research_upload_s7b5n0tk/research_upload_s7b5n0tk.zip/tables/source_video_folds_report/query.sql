SELECT * FROM "source_video_folds_report";

SELECT * FROM "fusion_model_output_current_figures_figure_summary";

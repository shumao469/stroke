SELECT * FROM "fold_3_figures_threshold_curve";

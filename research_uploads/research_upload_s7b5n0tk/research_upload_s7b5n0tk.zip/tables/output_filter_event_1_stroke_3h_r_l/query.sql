SELECT * FROM "output_filter_event_1_stroke_3h_r_l";

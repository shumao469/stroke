SELECT * FROM "output_filter_event_1_t_2s12h_l_2025_10_28_18_46_8_a";

SELECT * FROM "event_fusion_smoke_figures_roc_curve";

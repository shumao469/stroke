SELECT * FROM "fold_2_figures_threshold_curve";

SELECT * FROM "example_outputs_current_figures_pr_curve";

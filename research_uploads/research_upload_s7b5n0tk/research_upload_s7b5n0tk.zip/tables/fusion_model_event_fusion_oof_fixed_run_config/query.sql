SELECT * FROM "fusion_model_event_fusion_oof_fixed_run_config";

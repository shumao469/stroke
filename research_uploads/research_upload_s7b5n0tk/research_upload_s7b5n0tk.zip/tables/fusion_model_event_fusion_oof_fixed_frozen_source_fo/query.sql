SELECT * FROM "fusion_model_event_fusion_oof_fixed_frozen_source_fo";

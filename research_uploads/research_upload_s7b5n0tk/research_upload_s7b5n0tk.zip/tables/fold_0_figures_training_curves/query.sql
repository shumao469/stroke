SELECT * FROM "fold_0_figures_training_curves";

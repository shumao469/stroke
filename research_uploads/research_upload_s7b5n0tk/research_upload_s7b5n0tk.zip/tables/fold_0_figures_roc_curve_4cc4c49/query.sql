SELECT * FROM "fold_0_figures_roc_curve_4cc4c49";

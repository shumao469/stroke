SELECT * FROM "fusion_model_event_fusion_smoke_run_config";

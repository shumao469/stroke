SELECT * FROM "fusion_model_event_fusion_smoke_frozen_source_folds";

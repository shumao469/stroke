SELECT * FROM "fold_2_figures_figure_summary";

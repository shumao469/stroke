SELECT * FROM "event_fusion_oof_fixed_fold_0_fold_report";

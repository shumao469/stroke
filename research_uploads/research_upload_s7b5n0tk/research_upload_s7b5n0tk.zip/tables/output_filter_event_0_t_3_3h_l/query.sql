SELECT * FROM "output_filter_event_0_t_3_3h_l";

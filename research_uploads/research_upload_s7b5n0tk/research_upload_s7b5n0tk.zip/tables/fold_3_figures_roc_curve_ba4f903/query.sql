SELECT * FROM "fold_3_figures_roc_curve_ba4f903";

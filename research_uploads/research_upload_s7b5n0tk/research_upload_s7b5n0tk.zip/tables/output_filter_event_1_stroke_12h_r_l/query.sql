SELECT * FROM "output_filter_event_1_stroke_12h_r_l";

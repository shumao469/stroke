SELECT * FROM "example_outputs_current_figures_calibration_curve";
